// ***** DATA *****
let numbers = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 10, 11, 12],
    [13, 14, 15, 16],
    [13, 14, 15, 16]
]

// ***** SHOW DATA *****
function showData(){
    let print = ''

    // 1. Looping untuk mencetak angka + button samping
    for(let i=0; i<numbers.length; i++){
        print += '<tr>'
        for(let j=0; j<numbers.length; j++){
            print += `<td> ${numbers[i][j]} </td>`
        }
        print += `<td><input type="button" value="Sort" onClick="sortDataSampingAsc(${i})"></td>`
        print += '</tr>'
    }

    // 2. Cetak button yang ada di bawah
    print += '<tr>'
    for(let i=0; i<numbers.length; i++){
        print += `<td><input type="button" value="Sort" onClick="sortDataBawahAsc(${i})"></td>`
    }
    print += '</tr>'

    document.getElementById("table").innerHTML = print
}

showData()
